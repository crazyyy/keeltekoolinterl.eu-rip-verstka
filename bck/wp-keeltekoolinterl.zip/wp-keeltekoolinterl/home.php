<?php /* Template Name: Home Page */ get_header(); ?>


    <section id="hero" style="background-image:url(<?php the_field('home_header_background_img'); ?>);background-position: center 0;">
    <div class="inner">
        <div class="wrap">
            <div class="ctaArea" style="display:block;">
                <h1><?php the_field('home_header_title'); ?></h1>
                <?php the_field('home_header_content'); ?>
          
                <a href="<?php the_field('home_header_link_anchor'); ?>" class="btn btn-large btn-green"><?php the_field('home_header_link_text'); ?></a>
            </div>
            <?php get_template_part('sidebar-calendar'); ?>
        </div>
    </div>
</section>
</header><!-- begin #soorita-test -->

<section id="soorita-test" class="bg-gray padding-90">
    <div class="wrap">
        <h1><?php the_field('home_middle_title'); ?></h1>
        <?php the_field('home_middle_content'); ?>
        <a href="<?php the_field('home_middle_anchor_link'); ?>" class="btn btn-large btn-green"><?php the_field('home_middle_anchor_text'); ?></a>
    </div>
</section>
<!-- end #soorita-test -->    <!-- begin #kogemus-->
    <section id="kogemus" class="bg-white border-top border-bottom padding-90">
        <div class="wrap" style="background-image: url('<?php echo get_template_directory_uri(); ?>/img/20a-est.jpg')">
            <h1><?php the_field('home_middle_bottom_title'); ?></h1>
            <?php the_field('home_middle_bottom_content'); ?>
        </div>
    </section>
    <!-- end #kogemus-->

<!-- begin #kliendid-meist -->
<section id="kliendid-meist" class="bg-gray padding-90">
    <div class="wrap">
        <h1><?php the_field('user_review_title'); ?></h1>

        <div class="sliderHolder">

        <ul class="slides" style="height: 330px; position: relative; overflow: hidden;" id="testSlider">
        	<li style="position: absolute; top: 0px; left: 0px; display: block; z-index: 3; opacity: 1; width: 980px; height: 330px;">
                <!-- begin .block-grid -->
                <ul class="block-grid three-up clearfix">
                    <?php query_posts("showposts=3&cat=77"); ?>
                    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

        			<li>
                        <span class="quote"><?php wpeExcerpt('wpeExcerpt20'); ?></span>
                        <div class="author clearfix">
                            <?php if ( has_post_thumbnail()) :
                            the_post_thumbnail('medium'); 
                            else: ?>
                            <img src="<?php echo catchFirstImage(); ?>" title="<?php the_title(); ?>" width="77" height="77" class="attachment-testimonials wp-post-image" alt="<?php the_title(); ?>" />
                            <?php endif; ?>
                        <h4><?php the_title(); ?></h4>
                        <span><?php the_field('work'); ?></span>
                        </div>
                    </li>
                     
                    <?php endwhile; endif; ?>
                    <?php wp_reset_query(); ?>
                </ul>
                <!-- end .block-grid -->
            </li>
            <li style="position: absolute; top: 0px; left: 0px; display: block; z-index: 3; opacity: 1; width: 980px; height: 330px;">

                                            <!-- begin .block-grid -->
                <ul class="block-grid three-up clearfix">
                    <?php query_posts("showposts=3&cat=77&offset=3"); ?>
                    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

                    <li>
                        <span class="quote"><?php wpeExcerpt('wpeExcerpt20'); ?></span>
                        <div class="author clearfix">
                            <?php if ( has_post_thumbnail()) :
                            the_post_thumbnail('medium'); 
                            else: ?>
                            <img src="<?php echo catchFirstImage(); ?>" title="<?php the_title(); ?>" width="77" height="77" class="attachment-testimonials wp-post-image" alt="<?php the_title(); ?>" />
                            <?php endif; ?>
                        <h4><?php the_title(); ?></h4>
                        <span><?php the_field('work'); ?></span>
                        </div>
                    </li>
                     
                    <?php endwhile; endif; ?>
                    <?php wp_reset_query(); ?>
                </ul>
                <!-- end .block-grid -->
            </li>
        </ul>

        <div class="pagination" id="testNavi">
            <ul class="clearfix">
                <li class="current-item"><a href="http://multilingua.ee/#">1</a></li><li><a href="http://multilingua.ee/#">2</a></li>
            </ul>
        </div>
        </div><!-- sliderHolder -->
    </div>
</section>
<!-- end #kliendid-meist -->    <!-- begin #registreeri -->
    <section id="registreeri" class="bg-gray padding-90">
        <div class="wrap sep"></div>
        <div class="wrap">
            <div class="box box-orange">
                <h1><?php the_field('home_bottom_title'); ?></h1>
                <?php the_field('home_bottom_content'); ?>
                <a href="<?php the_field('home_bottom_anchor_link'); ?>" class="btn btn-large btn-green"><?php the_field('home_bottom_anchor_text'); ?></a>
            </div>
        </div>
    </section>
    <!-- end #registreeri -->

<?php get_footer(); ?>